import AppleWatchOrderForm from '@/components/AppleWatchOrderForm';

const Index = () => {
  return <AppleWatchOrderForm />;
};

export default Index;
