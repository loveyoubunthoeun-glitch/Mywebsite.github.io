import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { useToast } from '@/hooks/use-toast';

interface OrderFormData {
  fullName: string;
  phoneNumber: string;
  model: string;
  colorSize: string;
  address: string;
  paymentMethod: string;
  notes: string;
}

const AppleWatchOrderForm = () => {
  const [formData, setFormData] = useState<OrderFormData>({
    fullName: '',
    phoneNumber: '',
    model: '',
    colorSize: '',
    address: '',
    paymentMethod: '',
    notes: ''
  });
  const [isSubmitted, setIsSubmitted] = useState(false);
  const { toast } = useToast();

  const handleInputChange = (field: keyof OrderFormData, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.fullName || !formData.phoneNumber || !formData.model || !formData.address || !formData.paymentMethod) {
      toast({
        title: "សូមបំពេញព័ត៌មានឱ្យគ្រប់គ្រាន់",
        description: "មានវាលចាំបាច់ដែលមិនទាន់បំពេញ",
        variant: "destructive"
      });
      return;
    }

    setIsSubmitted(true);
    toast({
      title: "✅ ការបញ្ជាទិញរបស់អ្នកត្រូវបានទទួល!",
      description: "យើងនឹងទំនាក់ទំនងត្រឡប់ក្នុងរយៈពេលឆាប់ៗនេះ។"
    });
  };

  if (isSubmitted) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-background to-apple-gray flex items-center justify-center p-4">
        <Card className="w-full max-w-md shadow-lg">
          <CardContent className="text-center p-8">
            <div className="text-6xl mb-4">✅</div>
            <h2 className="text-2xl font-bold text-apple-red mb-2">
              ការបញ្ជាទិញរបស់អ្នកត្រូវបានទទួល!
            </h2>
            <p className="text-muted-foreground mb-6">
              យើងនឹងទំនាក់ទំនងត្រឡប់ក្នុងរយៈពេលឆាប់ៗនេះ។
            </p>
            
            <div className="space-y-4">
              <Button 
                variant="outline" 
                className="w-full rounded-full border-apple-red text-apple-red hover:bg-apple-red hover:text-white"
                asChild
              >
                <a href="https://t.me/AppleWatchShopBot" target="_blank" rel="noopener noreferrer">
                  💬 Chat Telegram
                </a>
              </Button>
              
              <Button 
                variant="outline" 
                className="w-full rounded-full border-apple-red text-apple-red hover:bg-apple-red hover:text-white"
                asChild
              >
                <a href="https://m.me/AppleWatchShop" target="_blank" rel="noopener noreferrer">
                  📧 Chat Messenger
                </a>
              </Button>
              
              <Button 
                variant="secondary" 
                className="w-full rounded-full"
                onClick={() => setIsSubmitted(false)}
              >
                បញ្ជាទិញថ្មី
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background to-apple-gray flex items-center justify-center p-4">
      <Card className="w-full max-w-2xl shadow-xl">
        <CardHeader className="text-center bg-gradient-to-r from-apple-red to-apple-red-hover text-white rounded-t-lg">
          <CardTitle className="text-2xl font-bold">
            📝 បំពេញព័ត៌មានដើម្បីបញ្ជាទិញ Apple Watch
          </CardTitle>
          <p className="text-white/90">Apple Watch Shop</p>
        </CardHeader>
        
        <CardContent className="p-8">
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Full Name */}
            <div className="space-y-2">
              <Label htmlFor="fullName" className="text-base font-medium">
                ឈ្មោះពេញ <span className="text-apple-red">*</span>
              </Label>
              <Input
                id="fullName"
                value={formData.fullName}
                onChange={(e) => handleInputChange('fullName', e.target.value)}
                className="rounded-full border-2 focus:border-apple-red"
                placeholder="បញ្ចូលឈ្មោះពេញរបស់អ្នក"
                required
              />
            </div>

            {/* Phone Number */}
            <div className="space-y-2">
              <Label htmlFor="phoneNumber" className="text-base font-medium">
                លេខទូរស័ព្ទ <span className="text-apple-red">*</span>
              </Label>
              <Input
                id="phoneNumber"
                value={formData.phoneNumber}
                onChange={(e) => handleInputChange('phoneNumber', e.target.value)}
                className="rounded-full border-2 focus:border-apple-red"
                placeholder="0XX XXX XXX"
                required
              />
            </div>

            {/* Model Selection */}
            <div className="space-y-2">
              <Label htmlFor="model" className="text-base font-medium">
                ជ្រើស Model <span className="text-apple-red">*</span>
              </Label>
              <Select onValueChange={(value) => handleInputChange('model', value)}>
                <SelectTrigger className="rounded-full border-2 focus:border-apple-red">
                  <SelectValue placeholder="ជ្រើសរើស Apple Watch Model" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="series9">Apple Watch Series 9</SelectItem>
                  <SelectItem value="se">Apple Watch SE / SE2</SelectItem>
                  <SelectItem value="s3-38">Apple Watch S3 38mm</SelectItem>
                  <SelectItem value="s3-42">Apple Watch S3 42mm</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Color and Size */}
            <div className="space-y-2">
              <Label htmlFor="colorSize" className="text-base font-medium">
                ពណ៌ និងទំហំ <span className="text-apple-red">*</span>
              </Label>
              <Select onValueChange={(value) => handleInputChange('colorSize', value)}>
                <SelectTrigger className="rounded-full border-2 focus:border-apple-red">
                  <SelectValue placeholder="ជ្រើសរើសពណ៌ និងទំហំ" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="black-41">ពណ៌ខ្មៅ - 41mm</SelectItem>
                  <SelectItem value="black-45">ពណ៌ខ្មៅ - 45mm</SelectItem>
                  <SelectItem value="black-49">ពណ៌ខ្មៅ - 49mm</SelectItem>
                  <SelectItem value="white-41">ពណ៌ស - 41mm</SelectItem>
                  <SelectItem value="white-45">ពណ៌ស - 45mm</SelectItem>
                  <SelectItem value="white-49">ពណ៌ស - 49mm</SelectItem>
                  <SelectItem value="gold-41">ពណ៌មាស - 41mm</SelectItem>
                  <SelectItem value="gold-45">ពណ៌មាស - 45mm</SelectItem>
                  <SelectItem value="gold-49">ពណ៌មាស - 49mm</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Address */}
            <div className="space-y-2">
              <Label htmlFor="address" className="text-base font-medium">
                អាសយដ្ឋានដឹកជញ្ជូន <span className="text-apple-red">*</span>
              </Label>
              <Textarea
                id="address"
                value={formData.address}
                onChange={(e) => handleInputChange('address', e.target.value)}
                className="rounded-lg border-2 focus:border-apple-red min-h-[100px]"
                placeholder="បញ្ចូលអាសយដ្ឋានពេញលេញ (ផ្ទះលេខ, ផ្លូវ, សង្កាត់, ខណ្ឌ, រាជធានី/ខេត្ត)"
                required
              />
            </div>

            {/* Payment Method */}
            <div className="space-y-4">
              <Label className="text-base font-medium">
                វិធីបង់ប្រាក់ <span className="text-apple-red">*</span>
              </Label>
              <RadioGroup 
                value={formData.paymentMethod} 
                onValueChange={(value) => handleInputChange('paymentMethod', value)}
                className="space-y-3"
              >
                <div className="flex items-center space-x-3 p-4 border border-gray-200 rounded-lg hover:bg-gray-50">
                  <RadioGroupItem value="cod" id="cod" className="border-apple-red text-apple-red" />
                  <Label htmlFor="cod" className="flex-1 cursor-pointer">
                    <span className="font-medium">COD (ទូទាត់ពេលទទួល)</span>
                    <br />
                    <span className="text-sm text-muted-foreground">បង់ប្រាក់នៅពេលទទួលមុខម្ហូប</span>
                  </Label>
                </div>
                
                <div className="flex items-center space-x-3 p-4 border border-gray-200 rounded-lg hover:bg-gray-50">
                  <RadioGroupItem value="bank" id="bank" className="border-apple-red text-apple-red" />
                  <Label htmlFor="bank" className="flex-1 cursor-pointer">
                    <span className="font-medium">ABA / Bank Transfer</span>
                    <br />
                    <span className="text-sm text-muted-foreground">លេខគណនី: 004255933 - Lysongeng</span>
                  </Label>
                </div>
              </RadioGroup>
            </div>

            {/* Notes */}
            <div className="space-y-2">
              <Label htmlFor="notes" className="text-base font-medium">
                កំណត់សម្គាល់បន្ថែម
              </Label>
              <Textarea
                id="notes"
                value={formData.notes}
                onChange={(e) => handleInputChange('notes', e.target.value)}
                className="rounded-lg border-2 focus:border-apple-red"
                placeholder="សម្គាល់ពិសេសអំពីការបញ្ជាទិញ (ប្រសិនបើមាន)"
              />
            </div>

            {/* Submit Button */}
            <Button 
              type="submit" 
              className="w-full bg-apple-red hover:bg-apple-red-hover text-white font-bold py-4 rounded-full text-lg shadow-red"
            >
              🔴 បញ្ជាទិញឥឡូវនេះ
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
};

export default AppleWatchOrderForm;